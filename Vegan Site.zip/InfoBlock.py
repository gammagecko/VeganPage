class InfoBlock:
    def __init__(self, url, title, category, state):
        self.url = url
        self.title = title
        self.category = category
        self.state = state
        
