import InfoBlock

class InfoBlocks:
    def __init__(self):
        self.arr = []
    
    def add(self, infoblock):
        self.arr.append(infoblock)
